# 🚀 ConstBOT Production Deployment Guide

## 📦 OPTION 1: NETLIFY DEPLOYMENT (RECOMMENDED)

### Why Netlify?
- ✅ Free tier includes serverless functions
- ✅ Environment variables for API keys
- ✅ Auto HTTPS
- ✅ Custom domains
- ✅ Easy updates via Git

### Step-by-Step:

#### 1. Prepare Your Files

Create this folder structure:
```
constbot/
├── index.html              (Your ConstBOT HTML file)
├── netlify.toml           (Configuration)
└── netlify/
    └── functions/
        └── ai-proxy.js    (Backend API proxy)
```

#### 2. Create netlify.toml

```toml
[build]
  functions = "netlify/functions"

[[redirects]]
  from = "/api/*"
  to = "/.netlify/functions/:splat"
  status = 200

[build.environment]
  NODE_VERSION = "18"
```

#### 3. Deploy

**Option A: Drag & Drop (Easiest)**
1. Go to https://netlify.com
2. Sign up / Login
3. Click "Add new site" → "Deploy manually"
4. Drag your `constbot` folder
5. Done!

**Option B: GitHub Integration (Best for updates)**
1. Push your code to GitHub
2. In Netlify: "Add new site" → "Import from Git"
3. Select your repo
4. Auto-deploys on every push!

#### 4. Set Environment Variables

In Netlify dashboard:
1. Site Settings → Environment Variables
2. Add these:
   - `GROQ_API_KEY` = your-groq-api-key
   - `ANTHROPIC_API_KEY` = your-anthropic-key (if using)
   - `OPENAI_API_KEY` = your-openai-key (if using)
   - `HUGGINGFACE_API_KEY` = your-hf-key (if using)

#### 5. Custom Domain (Optional)

1. Buy domain (namecheap.com, godaddy.com)
2. In Netlify: Domain settings → Add custom domain
3. Update DNS records as shown
4. Wait 24-48 hours for propagation

Your app: `https://constbot.yourdomain.com`

---

## 📦 OPTION 2: GITHUB PAGES (SIMPLER, NO BACKEND)

### Pros & Cons
✅ Completely free
✅ Simple setup
⚠️ No serverless functions (API keys exposed)
⚠️ Better for demo/testing only

### Steps:

1. **Create GitHub Repo**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/yourusername/constbot.git
   git push -u origin main
   ```

2. **Enable GitHub Pages**
   - Repo Settings → Pages
   - Source: Deploy from branch `main`
   - Folder: `/root`
   - Save

3. **Access Your App**
   `https://yourusername.github.io/constbot/`

4. **Custom Domain** (Optional)
   - Add CNAME file with your domain
   - Update DNS: `CNAME` record pointing to `yourusername.github.io`

---

## 📦 OPTION 3: VERCEL (BEST PERFORMANCE)

### Setup:

```bash
# Install Vercel CLI
npm install -g vercel

# In your project folder
vercel

# Follow prompts
# - Project name: constbot
# - Settings: Use defaults

# Production deployment
vercel --prod
```

### Environment Variables:
```bash
vercel env add GROQ_API_KEY
vercel env add ANTHROPIC_API_KEY
```

### Custom Domain:
1. Vercel Dashboard → Project → Settings → Domains
2. Add your domain
3. Update DNS as shown

---

## 📦 OPTION 4: YOUR OWN SERVER

### Using Node.js + Express:

```bash
# Setup
mkdir constbot-server
cd constbot-server
npm init -y
npm install express cors dotenv

# Create server.js
```

```javascript
// server.js
const express = require('express');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// API proxy endpoint
app.post('/api/ai-proxy', async (req, res) => {
  const { provider, prompt, projectData, documents } = req.body;
  
  const apiKey = process.env[`${provider.toUpperCase()}_API_KEY`];
  
  // Call AI API (same logic as Netlify function)
  // ... (use the ai-proxy.js code)
  
  res.json(response);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`ConstBOT running on port ${PORT}`);
});
```

Deploy to:
- **DigitalOcean App Platform**: $5/month
- **Heroku**: Free tier available
- **Railway**: Free tier available
- **AWS EC2**: Various pricing

---

## 🔒 SECURITY CHECKLIST

### ✅ Before Going Live:

1. **API Keys**
   - [ ] Move all API keys to environment variables
   - [ ] Never commit API keys to Git
   - [ ] Use backend proxy for API calls

2. **HTTPS**
   - [ ] Enable SSL (auto with Netlify/Vercel)
   - [ ] Force HTTPS redirects

3. **CORS**
   - [ ] Configure allowed origins
   - [ ] Don't use `*` in production

4. **Rate Limiting**
   - [ ] Implement request limits
   - [ ] Prevent API abuse

5. **Data Privacy**
   - [ ] Add privacy policy
   - [ ] Don't log sensitive data
   - [ ] Comply with GDPR if serving EU users

---

## 📊 COST COMPARISON

| Platform | Free Tier | Paid | Best For |
|----------|-----------|------|----------|
| **Netlify** | 100GB bandwidth, Functions | $19/mo | Full-stack apps |
| **Vercel** | 100GB bandwidth, Functions | $20/mo | High performance |
| **GitHub Pages** | Unlimited (1GB repo) | N/A | Static demos |
| **DigitalOcean** | N/A | $5/mo | Full control |

### AI API Costs (approximate):

- **Groq**: FREE (with limits)
- **HuggingFace**: FREE (with limits)
- **Anthropic Claude**: ~$3 per 1M tokens
- **OpenAI GPT-4**: ~$30 per 1M tokens

---

## 🎯 RECOMMENDED SETUP FOR CONSTBOT

### For MVP / Testing:
→ **Netlify Free Tier + Groq API**
- Cost: $0
- Setup time: 30 minutes
- Features: Full AI, serverless functions

### For Production:
→ **Netlify Pro + Groq/Anthropic**
- Cost: $19/month + API costs
- Setup time: 1 hour
- Features: Custom domain, better limits, support

### For Enterprise:
→ **Your Own Server + Multiple AI Providers**
- Cost: $50-200/month
- Setup time: 1 day
- Features: Full control, compliance, scaling

---

## 🚀 QUICK START (5 MINUTES)

Want to go live RIGHT NOW?

1. Go to https://netlify.com
2. Sign up with GitHub
3. Drag your ConstBOT folder
4. Add environment variable: `GROQ_API_KEY`
5. Share your link: `https://your-site.netlify.app`

Done! 🎉

---

## 📞 NEXT STEPS

1. Choose deployment option
2. Set up API key security
3. Test thoroughly
4. Get custom domain (optional)
5. Monitor usage
6. Scale as needed

Need help? The choice depends on:
- Budget: GitHub Pages (free) or Netlify (free + features)
- Features: Need backend? Use Netlify/Vercel
- Control: Want full control? Use own server
